// CBXManager.h
